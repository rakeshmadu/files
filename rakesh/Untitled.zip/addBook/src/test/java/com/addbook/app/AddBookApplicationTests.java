package com.addbook.app;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
