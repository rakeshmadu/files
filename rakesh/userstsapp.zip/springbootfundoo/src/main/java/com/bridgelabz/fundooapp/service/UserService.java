package com.bridgelabz.fundooapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bridgelabz.fundooapp.model.UserModel;
import com.bridgelabz.fundooapp.repository.UserRepository;

@Service
public class UserService implements IUserService {
    @Autowired
    UserRepository userRepo;

    @Override
    public String addUser(UserModel user) {
        // TODO Auto-generated method stub
        userRepo.save(user);
        return "user added successfully";
    }

    @Override
    public Optional<UserModel> getname(String name) {
        Optional<UserModel> getuserName = userRepo.findByName(name);

        return getuserName;
    }

    @Override
    public Optional<UserModel> getid(int id) {
        Optional<UserModel> getuserId = userRepo.findById(id);

        return getuserId;
    }

    @Override
    public Optional<UserModel> remove(String email) {
        Optional<UserModel> userModel = userRepo.findByEmail(email);
        userRepo.deleteByEmail(email);
        return userModel;

    }

    @Override
    public Optional<UserModel> delete(int id) {

        Optional<UserModel> userModel = userRepo.findById(id);
        userRepo.deleteById(id);
        return userModel;

    }

    @Override
    public UserModel update(UserModel user,String email) {
        user.setId(userRepo.findByEmail(email).get().getId());
        return userRepo.save(user);
    }

   

}
