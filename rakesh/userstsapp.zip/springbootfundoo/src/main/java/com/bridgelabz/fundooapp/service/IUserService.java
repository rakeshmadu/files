package com.bridgelabz.fundooapp.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.bridgelabz.fundooapp.model.UserModel;

@Service
public interface IUserService {

    String addUser(UserModel user);

    Optional<UserModel> getname(String name);
    Optional<UserModel> getid(int id);
    Optional<UserModel> remove(String email);
    Optional<UserModel> delete(int id);
    UserModel update(UserModel user,String email);
   
}
